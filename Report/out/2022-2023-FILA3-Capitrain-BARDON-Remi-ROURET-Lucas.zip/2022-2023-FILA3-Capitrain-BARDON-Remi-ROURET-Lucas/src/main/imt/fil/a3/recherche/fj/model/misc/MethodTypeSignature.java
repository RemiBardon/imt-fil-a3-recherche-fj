package imt.fil.a3.recherche.fj.model.misc;

import java.util.List;

public record MethodTypeSignature(List<String> parameterTypeNames, String returnTypeName) {
}
