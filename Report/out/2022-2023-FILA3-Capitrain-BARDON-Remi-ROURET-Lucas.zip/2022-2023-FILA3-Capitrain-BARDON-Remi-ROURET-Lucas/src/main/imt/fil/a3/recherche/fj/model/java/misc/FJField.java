package imt.fil.a3.recherche.fj.model.java.misc;

public record FJField(String type, String name) {
}
