package imt.fil.a3.recherche.fj.model.error;

/**
 * Type Error
 **/
public abstract class TypeError extends Throwable {
}
