package imt.fil.a3.recherche.fj.model.misc;

public record FieldInit(String fieldName, String argumentName) {
}
