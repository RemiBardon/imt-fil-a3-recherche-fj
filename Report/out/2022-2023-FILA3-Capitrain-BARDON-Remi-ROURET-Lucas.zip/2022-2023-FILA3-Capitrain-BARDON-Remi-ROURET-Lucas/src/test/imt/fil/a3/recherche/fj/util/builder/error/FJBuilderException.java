package imt.fil.a3.recherche.fj.util.builder.error;

public abstract class FJBuilderException extends Throwable {
}
