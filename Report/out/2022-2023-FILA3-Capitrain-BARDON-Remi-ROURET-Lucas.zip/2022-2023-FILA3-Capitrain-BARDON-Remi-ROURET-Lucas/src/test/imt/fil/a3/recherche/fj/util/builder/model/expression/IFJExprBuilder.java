package imt.fil.a3.recherche.fj.util.builder.model.expression;

import imt.fil.a3.recherche.fj.model.java.expression.FJExpr;
import imt.fil.a3.recherche.fj.util.builder.FJBuilder;

public interface IFJExprBuilder extends FJBuilder<FJExpr> { }
